package com.ds.val;

import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class MyData implements Runnable {

    private ArrayList<RateListener> listeners = new ArrayList();
    private Rates myRates;

    public MyData() {
        try {
            GetData();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void GetData() throws IOException {


    }

    @Override
    public void run() {
        //going to break down into class of it own
        try {
            URL url = new URL("http://data.fixer.io/api/latest?access_key=918009b5fe0f8d4e8cc95fde9d851090");
            HttpURLConnection http = (HttpURLConnection) url.openConnection();
            http.setRequestProperty("Accept", "application/json");

            Gson gson = new Gson();
            BufferedReader br = new BufferedReader(new InputStreamReader(url.openStream()));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line + "\n");
            }
            br.close();
            String jsonString = sb.toString();
            System.out.println(jsonString);

            myRates = gson.fromJson(jsonString, Rates.class);


            http.disconnect();
        } catch (IOException e) {
            
            e.printStackTrace();
        }

    }






    public void addListener(RateListener listener) {
        listeners.add(listener);
    }

    public void removeListener(RateListener listener) {
        listeners.remove(listener);
    }

}
