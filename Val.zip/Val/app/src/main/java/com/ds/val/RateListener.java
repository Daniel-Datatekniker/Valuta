package com.ds.val;

public interface RateListener {
    void OnUpdateRate(Rates rates);
    void OnStartRate(Rates rates);
}
