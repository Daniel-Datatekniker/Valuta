package com.ds.val;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements RateListener {

    private Thread myThread;
    private MyData mData;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mData = new MyData();
        mData.addListener(this);
        myThread = new Thread(mData);
        myThread.start();

    }

    @Override
    public void OnUpdateRate(Rates rates) {
        System.out.println("DKK");
        System.out.println(rates.getRates().getDkk());
    }

    @Override
    public void OnStartRate(Rates rates) {
        System.out.println("DKK");
        System.out.println(rates.getRates().getDkk());
    }
}